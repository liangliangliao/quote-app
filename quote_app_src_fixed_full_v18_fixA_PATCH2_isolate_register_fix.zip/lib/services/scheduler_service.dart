
import 'dart:isolate';
import 'dart:ui';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'package:intl/intl.dart';
import '../data/dao.dart';
import '../data/db.dart';
import '../services/notification_service.dart';
import '../services/openai_service.dart';
import 'package:sqflite/sqflite.dart';

const String _isolateName = 'task_alarm_isolate';
SendPort? _uiSendPort;

class SchedulerService {
  static Future<void> init() async {
    await AndroidAlarmManager.initialize();
    IsolateNameServer.removePortNameMapping(_isolateName);
    final port = ReceivePort();
    IsolateNameServer.registerPortWithName(port.sendPort, _isolateName);
    port.listen((_){});
  }

  /// Schedule/Reschedule next tick for ALL tasks at their exact minute.
  /// Uses one-shot exact alarm and reschedules itself after handling.
  static Future<void> scheduleNextForAll() async {
    final dao = TaskDao();
    final tasks = await dao.all();
    final now = DateTime.now();
    for (final t in tasks) {
      if ((t['status'] ?? 'open') != 'open') continue;
      final next = _nextTrigger(now, t['start_time'] as String);
      if (next == null) continue;
      final id = (t['task_uid'] as String).hashCode & 0x7fffffff;
      await AndroidAlarmManager.oneShotAt(
        next,
        id,
        callback,
        exact: true,
        wakeup: true,
        rescheduleOnReboot: true,
        allowWhileIdle: true,
      );
    }
  }

  static DateTime? _nextTrigger(DateTime now, String hhmmIso) {
    // hhmmIso is "yyyy-MM-dd HH:mm" or "yyyy-MM-ddTHH:mm"
    final s = hhmmIso.replaceFirst('T', ' ');
    DateTime base;
    try {
      base = DateTime.parse(s.length>=16 ? s.substring(0,16).replaceFirst(' ', 'T') : s);
    } catch (_) {
      return null;
    }
    final DateTime todayAt = DateTime(now.year, now.month, now.day, base.hour, base.minute);
    if (todayAt.isAfter(now)) return todayAt;
    // else schedule tomorrow same time
    final tomorrow = todayAt.add(const Duration(days: 1));
    return tomorrow;
  }

  @pragma('vm:entry-point')
  static Future<void> callback() async {
    // Scan tasks that match current minute, then send notifications accordingly.
    final now = DateTime.now();
    final hhmm = DateFormat('HH:mm').format(now);
    final tasks = await TaskDao().all();
    final cfg = await ConfigDao().getOne();
    for (final t in tasks) {
      if ((t['status'] ?? 'open') != 'open') continue;
      final st = (t['start_time'] as String);
      final stHm = st.split('T').last.split(':').take(2).join(':');
      if (stHm != hhmm) continue;

      final type = t['type'] as String;
      final name = (t['name'] ?? '') as String;
      final avatar = (t['avatar_path'] ?? '') as String;
      final taskUid = (t['task_uid'] as String);

      if (type == 'manual') {
        // read latest quote for this task
        // For manual, we expect a quote row linked to taskUid
        // If none, skip.
        // Here simply take the latest quote of this task.
        // Not inserting new rows.
        final db = await AppDatabase.instance();
        final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id DESC', limit: 1);
        if (rows.isEmpty) continue;
        final content = (rows.first['content'] ?? '') as String;
        await NotificationService.show(id: taskUid.hashCode & 0x7fffffff, title: name, body: content, largeIconPath: avatar);
        await QuoteDao().markNotifiedByUid(rows.first['quote_uid'] as String);
      } else if (type == 'carousel') {
        // cycle through quotes for this task
        final db = await AppDatabase.instance();
        final metaKey = 'carousel_index_$taskUid';
        // simple meta table
        await db.execute('CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT)');
        final metaRows = await db.query('meta', where: 'key=?', whereArgs: [metaKey], limit: 1);
        int index = 0;
        if (metaRows.isNotEmpty) {
          index = int.tryParse((metaRows.first['value'] ?? '0') as String) ?? 0;
        }
        final rows = await db.query('quotes', where: 'task_uid=?', whereArgs: [taskUid], orderBy: 'id ASC');
        if (rows.isEmpty) continue;
        final row = rows[index % rows.length];
        final content = (row['content'] ?? '') as String;
        final av = (row['avatar_path'] as String?) ?? avatar;
        await NotificationService.show(id: taskUid.hashCode & 0x7fffffff, title: name, body: content, largeIconPath: av);
        await db.insert('meta', {'key': metaKey, 'value': ((index+1)%rows.length).toString()}, conflictAlgorithm: ConflictAlgorithm.replace);
      } else {
        // auto -> call openai up to 10 attempts for unique content
        final prompt = (t['prompt'] ?? '') as String;
        final apiKey = (cfg['api_key'] ?? '') as String;
        final endpoint = ((cfg['endpoint'] ?? '') as String).isNotEmpty ? cfg['endpoint'] as String : 'https://api.openai.com/v1/chat/completions';
        final model = (cfg['model'] ?? 'gpt-5') as String;
        final openai = OpenAIService(endpoint: endpoint, apiKey: apiKey, model: model);

        String? content;
        for (var i=0;i<10;i++){
          try {
            final resp = await openai.generateQuote(prompt.isEmpty ? '给我一句中文名人名言。' : prompt);
            // dedup
            final ok = !(await QuoteDao().existsSimilar(resp));
            if (ok) { content = resp.trim(); break; }
          } catch (e) {
            await LogDao().add(taskUid: taskUid, detail: '错误! 调用API失败: $e');
            content = null;
            break;
          }
        }
        if (content == null) {
          await LogDao().add(taskUid: taskUid, detail: '错误! 连续调用api10次去重检验未通过！');
          continue;
        }
        final uid = await QuoteDao().insertIfUnique(
          taskUid: taskUid,
          type: type,
          taskName: name,
          avatarPath: avatar,
          content: content,
        );
        await LogDao().add(taskUid: taskUid, detail: uid==null ? '错误! 插入名言失败（可能重复）' : '成功!');
        if (uid != null) {
          await NotificationService.show(id: taskUid.hashCode & 0x7fffffff, title: name, body: content, largeIconPath: avatar);
          await QuoteDao().markNotifiedByUid(uid);
        }
      }
    }

    // After handling, schedule next alarms
    await scheduleNextForAll();
  }
}
