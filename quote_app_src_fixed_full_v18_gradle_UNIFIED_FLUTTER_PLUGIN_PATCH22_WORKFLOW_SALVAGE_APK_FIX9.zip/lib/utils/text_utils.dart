
import 'dart:math';

String normalizeText(String s) {
  var t = s;
  t = t.replaceAll(RegExp(r'\s+'), ' ').trim();
  // unify quotes and punctuation
  t = t.replaceAll('“', '"').replaceAll('”', '"').replaceAll('’', "'").replaceAll('‘', "'");
  // to half-width basic Latin where reasonable - minimal
  return t.toLowerCase();
}

/// Jaro-Winkler similarity, returns [0,1]
double jaroWinkler(String s1, String s2) {
  if (s1 == s2) return 1.0;
  final m = _matches(s1, s2);
  if (m == 0) return 0.0;
  final t = _transpositions(s1, s2) / 2.0;
  final j = (m / s1.length + m / s2.length + (m - t) / m) / 3.0;
  final l = _commonPrefixLength(s1, s2, 4);
  return j + l * 0.1 * (1 - j);
}

int _matchDistance(int len) => max((len / 2).floor() - 1, 0);

int _matches(String s1, String s2) {
  final matchDist = _matchDistance(max(s1.length, s2.length));
  final s1Matches = List<bool>.filled(s1.length, false);
  final s2Matches = List<bool>.filled(s2.length, false);
  var matches = 0;
  for (var i = 0; i < s1.length; i++) {
    final start = max(0, i - matchDist);
    final end = min(i + matchDist + 1, s2.length);
    for (var j = start; j < end; j++) {
      if (s2Matches[j]) continue;
      if (s1[i] != s2[j]) continue;
      s1Matches[i] = true;
      s2Matches[j] = true;
      matches++;
      break;
    }
  }
  return matches;
}

int _transpositions(String s1, String s2) {
  final matchDist = _matchDistance(max(s1.length, s2.length));
  final s1Matches = List<bool>.filled(s1.length, false);
  final s2Matches = List<bool>.filled(s2.length, false);
  final s1Chars = <String>[];
  final s2Chars = <String>[];
  for (var i = 0; i < s1.length; i++) {
    final start = max(0, i - matchDist);
    final end = min(i + matchDist + 1, s2.length);
    for (var j = start; j < end; j++) {
      if (s2Matches[j]) continue;
      if (s1[i] != s2[j]) continue;
      s1Matches[i] = true;
      s2Matches[j] = true;
      s1Chars.add(s1[i]);
      break;
    }
  }
  for (var j = 0; j < s2.length; j++) {
    final start = max(0, j - matchDist);
    final end = min(j + matchDist + 1, s1.length);
    for (var i = start; i < end; i++) {
      if (!s1Matches[i]) continue;
      if (s2[j] != s1[i]) continue;
      s2Matches[j] = true;
      s2Chars.add(s2[j]);
      break;
    }
  }
  var t = 0;
  for (var i = 0; i < min(s1Chars.length, s2Chars.length); i++) {
    if (s1Chars[i] != s2Chars[i]) t++;
  }
  return t;
}

int _commonPrefixLength(String s1, String s2, int maxLen) {
  var l = 0;
  for (; l < min(min(s1.length, s2.length), maxLen); l++) {
    if (s1[l] != s2[l]) break;
  }
  return l;
}
