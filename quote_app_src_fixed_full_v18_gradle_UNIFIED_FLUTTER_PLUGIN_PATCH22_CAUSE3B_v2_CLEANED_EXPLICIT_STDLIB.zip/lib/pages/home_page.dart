
import 'dart:async';
import 'package:flutter/material.dart';
import '../data/dao.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Map<String,dynamic>? _latest;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    _latest = await QuoteDao().latestOne();
    if (mounted) setState((){});
  }

  @override
  Widget build(BuildContext context) {
    if (_latest == null) {
      return const Center(child: Text('暂无数据！'));
    }
    return Padding(
      padding: const EdgeInsets.all(16),
      child: SingleChildScrollView(
        child: Text(
          (_latest!['content'] ?? '') as String,
          style: const TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
