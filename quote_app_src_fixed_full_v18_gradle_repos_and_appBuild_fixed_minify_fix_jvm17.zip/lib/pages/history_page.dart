
import 'package:flutter/material.dart';
import '../data/dao.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  final _dao = QuoteDao();
  final _scroll = ScrollController();
  String _q = '';
  List<Map<String,dynamic>> _items = [];
  int _offset = 0;
  bool _loading = false;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _loadMore();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 100 && !_loading && !_done) {
        _loadMore();
      }
    });
  }

  Future<void> _loadMore() async {
    _loading = true;
    final rows = await _dao.latest(limit: 100, offset: _offset, q: _q.isEmpty ? null : _q);
    _offset += rows.length;
    _items.addAll(rows);
    _loading = false;
    if (mounted) setState((){});
    if (rows.length < 100) _done = true;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: TextField(
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: '搜索'),
            onChanged: (v){
              _q = v;
              _items.clear();
              _offset = 0;
              _done = false;
              _loadMore();
            },
          ),
        ),
        Expanded(
          child: ListView.builder(
            controller: _scroll,
            itemCount: _items.length,
            itemBuilder: (_, i){
              final e = _items[i];
              return ListTile(
                title: Text((e['task_name'] ?? '') as String),
                subtitle: Text((e['content'] ?? '') as String, maxLines: 3, overflow: TextOverflow.ellipsis),
              );
            },
          ),
        )
      ],
    );
  }
}
