#!/usr/bin/env bash
set -euxo pipefail
cd "$(dirname "$0")/.."

if [ -f android/gradlew ]; then
  chmod +x android/gradlew || true
fi

# Ensure no v1 embedding markers
! grep -R "io.flutter.app" -n . || (echo "::error::Found io.flutter.app"; exit 1)
! grep -R "FlutterApplication" -n . || (echo "::error::Found FlutterApplication"; exit 1)
! grep -R "GeneratedPluginRegistrant" -n . || (echo "::error::Found GeneratedPluginRegistrant"; exit 1)

echo "[ok] prebuild_verify passed."
