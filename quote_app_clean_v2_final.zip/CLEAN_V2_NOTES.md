# Clean V2 Project Notes
