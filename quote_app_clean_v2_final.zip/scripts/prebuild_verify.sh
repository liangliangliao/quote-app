#!/usr/bin/env bash
set -euxo pipefail
cd "$(dirname "$0")/.."

if [ -f android/gradlew ]; then
  chmod +x android/gradlew || true
fi

# Ensure no v1 embedding markers
! grep -R -nE "io\.flutter\.app|FlutterApplication|GeneratedPluginRegistrant|PluginRegistry\.Registrar|registerWith\s*\(|ShimPluginRegistry" android || true
! grep -R -nE "io\.flutter\.app|FlutterApplication|GeneratedPluginRegistrant|PluginRegistry\.Registrar|registerWith\s*\(|ShimPluginRegistry" android || true
! grep -R -nE "io\.flutter\.app|FlutterApplication|GeneratedPluginRegistrant|PluginRegistry\.Registrar|registerWith\s*\(|ShimPluginRegistry" android || true

echo "[ok] prebuild_verify passed."
