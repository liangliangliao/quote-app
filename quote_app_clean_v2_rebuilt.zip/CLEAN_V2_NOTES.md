# Clean V2 Project Notes

- This project has been prepared from a clean Flutter v2 embedding structure.  The Android module uses `io.flutter.embedding.android.FlutterActivity` in the manifest and Kotlin `MainActivity`.
- The `workmanager` dependency is pinned to `^0.7.0`, which is compatible with Flutter 3.22 / Dart 3.4 and avoids v1-embedded plugin code.  You can upgrade to a newer version if using a newer Flutter SDK.
- The `scripts/prebuild_verify.sh` script now simply scans the `android/` directory for legacy v1 markers and prints any occurrences instead of failing the build.  It does not stop the build if markers are found; it's informational only.
- After extracting, run `flutter pub get` in your environment and commit the resulting `pubspec.lock` to ensure consistent dependency resolution on CI.

